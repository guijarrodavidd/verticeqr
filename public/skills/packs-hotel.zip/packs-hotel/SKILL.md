---
name: packs-hotel
description: Prepara packs para parejas, familias y celebraciones con lo que el hotel ya tiene, como la cena en la habitación, el cava, la salida tardía o una noche de cine con palomitas, con la cuenta del precio, quién lo prepara y el mensaje para ofrecerlo en español y en inglés. Úsala cuando pidan crear packs, ofertas para aniversarios o cumpleaños, o planes para familias.
---

# Packs para parejas, familias y celebraciones

Juntas en un solo plan cosas que el hotel ya vende por separado, para que el huésped lo pida de una vez.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- La carta del restaurante y del bar, con precios.
- Los extras que ya vende el hotel, con precio: mejoras, salida tardía, parking, spa, bicis, traslados.
- Qué huésped recibe y en qué fechas (aniversarios, San Valentín, vacaciones escolares).
- Qué puede preparar el equipo sin complicarse y cuánto tarda.

## Cómo los preparas

1. Propón entre 6 y 8 packs, con al menos 2 para parejas, 2 para familias y 1 para celebraciones.
2. Cada pack se hace con cosas que el hotel ya vende o puede comprar fácil. Si propones algo nuevo (palomitas, globos, una tarjeta escrita a mano), ponlo aparte con lo que costaría conseguirlo.
3. Haz la cuenta de cada pack: el precio de cada cosa por separado y la suma. Si propones un precio de pack más bajo que la suma, enséñalo como propuesta y comprueba que sigue por encima de lo que cuesta.
4. Di quién lo prepara (cocina, bar, recepción, pisos) y con cuánta antelación hay que pedirlo.
5. Escribe el mensaje para ofrecerlo al reservar y al llegar, con 40 palabras como mucho.

## Cómo los entregas

1. Los packs con su nombre, para quién son, qué incluyen, quién los prepara y la cuenta.
2. Los mensajes en español y en inglés.
3. Un bloque final, PARA REVISAR ANTES DE OFRECERLO, con los precios que faltan y los packs que dependen de que haya habitación libre.

## Reglas

- La cuenta tiene que cerrar. Revisa cada suma antes de entregar.
- No prometas nada que el equipo no pueda preparar en el tiempo que dices.
