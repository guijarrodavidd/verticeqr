---
name: servicio-habitacion
description: Prepara la carta de servicio de habitación de un hotel a partir de su carta del restaurante o de una lista de platos. Elige qué platos llegan bien a la habitación, los ordena para que el huésped pida más, escribe descripciones cortas y la deja en español y en inglés. Úsala cuando pidan montar, revisar o mejorar la carta de room service o de habitación.
---

# Carta de servicio de habitación

Preparas la carta que el huésped ve en su habitación. Trabajas solo con los platos y los precios que te da el hotel.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- La carta actual del restaurante o del bar, con precios.
- El horario en que cocina puede servir en la habitación.
- Si se cobra algo por subir el pedido.
- Los platos que más se venden, si lo sabe.
- Los alérgenos de cada plato, si los tiene.
- Cómo trata el hotel al huésped, de tú o de usted. Si no lo sabes, de usted.

## Cómo la preparas

1. Revisa plato a plato si llega bien a la habitación en unos 20 minutos. Los que pierden mucho por el camino (fritos, arroces, helados) los marcas como «dudoso» con el motivo. Eso lo decide cocina.
2. Ordena por momentos del día: desayuno, para picar, comidas y cenas, postres, bebidas y, si el hotel recibe familias, niños. Dentro de cada sección, primero los que más se venden.
3. Cada plato lleva su nombre, una línea de descripción de 12 palabras como mucho (el ingrediente principal y cómo se hace), el precio y los alérgenos si los hay.
4. Propón 2 o 3 combinaciones para pedir de una vez, como una cena para dos con una botella. Usa solo platos de la carta y escribe la suma exacta de sus precios. Si propones un precio cerrado distinto de la suma, márcalo como propuesta para que lo decida el director.
5. Haz la versión en inglés. Los nombres de platos típicos se quedan en español y se explican al lado, por ejemplo «Arroz a banda · rice cooked in fish stock».

## Cómo la entregas

1. La carta en español, por secciones.
2. La misma carta en inglés.
3. Las combinaciones, con la cuenta de cada una.
4. Un bloque final, PARA REVISAR ANTES DE PUBLICARLA, con los platos dudosos, los precios que faltan y el aviso de que los alérgenos los confirma siempre cocina.

## Reglas

- No inventes platos, precios ni alérgenos. Si falta un precio, escribe «precio a confirmar».
- Descripciones sencillas, sin adjetivos de relleno como «delicioso» o «exquisito».
- Revisa cada suma antes de entregar.
