---
name: guia-zona
description: Escribe la guía de la zona de un hotel, contada desde el hotel, con lo que el director y su equipo recomiendan de verdad, como qué ver cerca, dónde comer, qué hacer con niños o si llueve y cómo llegar desde la puerta, en español y en inglés. Une cada recomendación con lo que vende el hotel cuando encaja, como bicis, traslados o experiencias. Úsala cuando pidan la guía de la zona, recomendaciones para huéspedes o la sección de la zona de la carta.
---

# La guía de tu zona

Escribes la guía que el huésped lee en la habitación, como se la contaría alguien de recepción que conoce bien la zona.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- La dirección del hotel.
- Lo que recomiendan el director y el equipo: el sitio, por qué lo recomiendan y cómo se llega.
- Cómo se mueve el huésped: andando, en coche, en taxi, en bus o en bici.
- Lo que vende el hotel que encaja con salir: bicis, traslados, picnic, experiencias.
- Cómo trata el hotel al huésped, de tú o de usted. Si no lo sabes, de usted.

## Cómo la preparas

1. Ordena por situaciones: a 10 minutos andando, para un día entero, con niños, si llueve, para cenar fuera y para el último día.
2. Cada recomendación lleva qué es, por qué la recomienda el hotel, cómo llegar desde la puerta y cuánto se tarda.
3. Donde encaje, añade lo que el hotel vende para ese plan («Si prefieren ir en bici, en recepción las alquilamos por [precio] al día»). Una vez por sección como mucho, sin forzarlo.
4. Escribe en frases cortas, como habla alguien de recepción.

## Cómo la entregas

1. La guía en español, por situaciones.
2. La misma guía en inglés.
3. Un bloque final, PARA COMPROBAR ANTES DE PUBLICARLA, con horarios, precios, distancias y sitios que pueden haber cerrado.

## Reglas

- No inventes sitios, horarios, precios ni distancias. Lo que no te haya dado el hotel va marcado para comprobar.
- Si puedes buscar en internet, úsalo para comprobar horarios y distancias, y di de dónde lo has sacado.
