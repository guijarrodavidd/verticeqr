---
name: mejoras-habitacion
description: Prepara las mejoras que un hotel puede venderle al huésped durante su estancia, como subir de habitación, la entrada anticipada y la salida tardía, con su precio, sus condiciones y los mensajes para ofrecerlas en español y en inglés. Úsala cuando pidan poner precio a una mejora, crear la oferta de salida tardía o escribir cómo ofrecerlas antes de llegar, en recepción o la noche antes de irse.
---

# Mejoras de la estancia

Preparas lo que el huésped puede pagar para estar mejor: otra habitación, entrar antes o salir más tarde.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- Los tipos de habitación y lo que tiene de más cada uno: metros, vistas, terraza, bañera, cama.
- La tarifa media de cada tipo, por temporada si la tiene.
- Las horas de entrada y de salida.
- Lo que ya cobra hoy por mejoras, si cobra algo.
- Qué días suele quedar libre cada tipo de habitación.
- Cómo trata el hotel al huésped, de tú o de usted. Si no lo sabes, de usted.

## Cómo las preparas

1. Haz la escalera de mejoras: de qué habitación a cuál, y qué gana el huésped dicho en concreto («terraza con vistas al mar», nunca «más confort»).
2. Pon precio por noche a cada mejora. Si el hotel ya tiene precio, usa ese. Si no, como punto de partida propón entre un tercio y la mitad de la diferencia de tarifa entre las dos habitaciones, y enseña la cuenta. El precio final lo decide el director.
3. Prepara la entrada anticipada y la salida tardía en dos tramos (por ejemplo, hasta las 14:00 y hasta las 18:00), con precio y condición. Siempre según disponibilidad y confirmado por recepción.
4. Escribe los mensajes para tres momentos: antes de llegar, en el mostrador de recepción y la noche antes de la salida. Cada uno con 40 palabras como mucho, el precio y cómo pedirlo.

## Cómo las entregas

1. Una tabla de mejoras: de, a, qué gana el huésped, precio por noche y de dónde sale ese precio.
2. La entrada anticipada y la salida tardía, con tramos, precios y condiciones.
3. Los mensajes en español y en inglés.
4. Un bloque final, PARA REVISAR ANTES DE USARLO, con los precios que has propuesto tú y los días en que conviene no ofrecer una mejora porque esa habitación se llena.

## Reglas

- Nunca prometas una mejora gratis ni una habitación concreta.
- Todo lo que dependa de que haya habitación libre lleva «según disponibilidad».
- No inventes tarifas. Si falta una, pídela.
