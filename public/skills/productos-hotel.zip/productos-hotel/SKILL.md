---
name: productos-hotel
description: Prepara el catálogo de productos que el huésped se puede llevar a casa o pedir a la habitación, como productos de la zona, el aceite o el vino que se sirven en el hotel, amenities y kits de playa o de cumpleaños, con precio, forma de entrega y ficha en español y en inglés. Úsala cuando pidan vender productos en el hotel, montar una pequeña tienda o crear kits.
---

# Productos del hotel

Preparas lo que el huésped puede comprar para llevarse a casa o para usar durante su estancia.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- Lo que ya usa el hotel y le gusta al huésped: aceite, vino, café, jabones, almohada, albornoz.
- Los productores de la zona con los que trabaja o que conoce.
- Lo que le cuesta cada producto, si lo sabe.
- Dónde puede guardar algo de stock y quién lo entrega.

## Cómo lo preparas

1. Propón entre 6 y 10 productos en tres grupos: lo que el huésped ya ha probado en el hotel, lo típico de la zona y kits para un momento concreto (playa, picnic, cumpleaños, viaje con bebé).
2. Pon el precio con su cuenta: coste más margen. El margen lo decide el director. Si no te lo da, deja el hueco y enseña cómo quedaría con el que elija.
3. Di cómo se entrega cada uno: en la habitación, en recepción o al irse.
4. Escribe la ficha de cada producto: nombre, una línea de por qué es de este hotel, tamaño y precio.
5. Propón cómo empezar sin llenar un almacén: pocas unidades de prueba o pedido al proveedor cuando el huésped lo compra.

## Cómo lo entregas

1. El catálogo por grupos, en español y en inglés.
2. La cuenta del precio de cada producto.
3. Un bloque final, PARA REVISAR ANTES DE VENDERLO, con los costes que faltan, quién repone y el aviso de consultar qué hace falta para vender comida o alcohol.

## Reglas

- No inventes marcas, productores ni costes.
- Nada que el equipo no pueda guardar o entregar sin complicarse.
