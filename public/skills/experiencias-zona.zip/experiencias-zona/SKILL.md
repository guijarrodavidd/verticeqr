---
name: experiencias-zona
description: Prepara las experiencias que un hotel puede vender a sus huéspedes junto con negocios de su zona, como rutas, catas, salidas en barco, clases o masajes, con su precio de venta, el mensaje para proponer el acuerdo a cada negocio y la ficha de cada experiencia en español y en inglés. Úsala cuando pidan ideas de experiencias, montar acuerdos con negocios locales o ponerlas en la carta del hotel.
---

# Experiencias con negocios de tu zona

Preparas los planes que el huésped puede reservar desde el hotel con negocios de alrededor, y lo que el hotel se queda por cada uno.

## Lo que necesitas

Si falta algo de esta lista, pídelo todo en un solo mensaje antes de empezar:

- Dónde está el hotel y cómo se mueve el huésped: andando, en coche, en taxi.
- Qué huésped recibe sobre todo: parejas, familias, gente de trabajo, grupos.
- Los negocios con los que ya trabaja o que conoce, con lo que cobran si lo sabe.
- Lo que más preguntan los huéspedes en recepción.
- La temporada.

## Cómo las preparas

1. Propón entre 8 y 12 experiencias, ordenadas por tipo de huésped y por momento (mañana, tarde, día de lluvia).
2. Para cada una, di qué tipo de negocio la puede dar. Si el director te ha dado nombres, úsalos. Si no, escribe el tipo de negocio («una bodega a menos de 30 minutos») y no inventes nombres.
3. Pon el precio al huésped con su cuenta: lo que cobra el negocio más lo que se queda el hotel. Lo que se queda el hotel lo acuerda el director con cada negocio, así que si no te lo ha dicho déjalo como hueco.
4. Escribe el mensaje para proponer el acuerdo a cada negocio: quién es el hotel, cuántos huéspedes recibe, qué le propone y cómo se reservaría. 80 palabras como mucho.
5. Escribe la ficha de cada experiencia para la carta: nombre, qué incluye, cuánto dura, precio, cómo se reserva y con cuánta antelación.

## Cómo las entregas

1. La lista de experiencias, por tipo de huésped.
2. Los mensajes para los negocios.
3. Las fichas en español y en inglés.
4. Un bloque final, PARA CONFIRMAR CON CADA NEGOCIO, con precios, horarios, plazas y forma de pago.

## Reglas

- No inventes negocios, horarios ni precios. Lo que no sepas va marcado para confirmar.
- Si puedes buscar en internet, úsalo para proponer tipos de negocio que haya en la zona, y avisa de que hay que llamarles antes de venderlo.
